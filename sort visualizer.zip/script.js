let currentRoundConfig = {
    elementCount: 10,
    maxElement: 10,
    sortName: "Bubble sort",
    canciled: false,
    stopped: false,
    noticeFunction: null
}

const inputs = {
    sortSelector: null,
    sortDelaySelect: null,
    elementCountInput: null,
    maxElementInput: null,
    startButton: null
}

let array = [];
let transformArray = [] // not in pixels, but in elements
let referenceArray = []
let elementsDiv = null;
const SORTING_STATE = 0;
const STOP_STATE = 1;
const PRESORT_STATE = 2;
let state = PRESORT_STATE;
let sortDelay = 500;
let elements = null;

function genArray() {
    array = [];
    for (let i = 0; i < currentRoundConfig.elementCount; i++) {
        array[i] = Math.floor(Math.random() * currentRoundConfig.maxElement);
        transformArray[i] = 0;
        referenceArray[i] = i;
    }
}

function calcElementWidth() { // in %
    return Math.min(3.0, 100.0 / currentRoundConfig.elementCount);
}

function calcElementMargin() {
    return calcElementWidth() / 10;
}

function createElementsFromArray() {
    let elementWidth = calcElementWidth();
    let elementMargin = calcElementMargin();
    elementsDiv.empty();
    for (let i = 0; i < array.length; i++) {
        let elementHeight = (array[i] * 1.0 / currentRoundConfig.maxElement) * 100;
        elementsDiv.append(`<div class=\"element\" style=\"width: ${elementWidth}%; height: ${elementHeight}%; margin-right:${elementMargin}\"></div>`);
        elementsDiv.last().css("margin-right", "0")
    }
}

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function getElement(index) {
    return $(`.element:nth-child(${referenceArray[index] + 1})`);
}

function highligthElement(index) {
    let element = getElement(index);
    element.css("background-color", "white");
    element.css("border-color", "black");
}

function unhighligthElement(index) {
    let element = getElement(index);
    element.css("background-color", "black");
    element.css("border-color", "white");
}

function setElementHeight(index, height) {
    getElement(index).css("height", `${height * 100.0 / currentRoundConfig.maxElement}%`);
}

function swap(index1, index2) {
    let difference = referenceArray[index2] - referenceArray[index1];
    transformArray[index1] += difference;
    transformArray[index2] -= difference;
    let c = array[index1]
    array[index1] = array[index2]
    array[index2] = c
    c = referenceArray[index1]
    referenceArray[index1] = referenceArray[index2]
    referenceArray[index2] = c
    let spacing = elementsDiv.width() * 1.0 / currentRoundConfig.elementCount;
    getElement(index1).css("transform", `translateX(${-spacing * transformArray[index1]}px)`)
    getElement(index2).css("transform", `translateX(${-spacing * transformArray[index2]}px)`)
}

let messageClearFuncId;
let messageElement = null;
function message(mes) {
    messageElement.text(mes);
    clearTimeout(messageClearFuncId)
    messageClearFuncId = setTimeout(function () {
        messageElement.text("")
    }, 2000);
}


function setup() {
    elementsDiv = $(".elements");
    inputs.sortSelector = $(".sort-selector");
    inputs.sortDelaySelect = $(".sort-delay-input");
    inputs.elementCountInput = $(".element-count-input");
    inputs.maxElementInput = $(".max-element-input");
    inputs.startButton = $(".start-button");

    inputs.sortDelaySelect.val(sortDelay);
    inputs.elementCountInput.val(currentRoundConfig.elementCount);
    inputs.maxElementInput.val(currentRoundConfig.maxElement);

    inputs.sortDelaySelect.on("change", function () {
        sortDelay = Math.max(10, inputs.sortDelaySelect.val());
        elements.css("transition", `all ${sortDelay * 0.8} s`)
    })

    messageElement = $(".message");
    elements = $(".element");
}

function bubbleSort(i, j, curRoundConfig) {
    if (curRoundConfig.canciled) {
        handleNewState(PRESORT_STATE);
        return;
    }

    temp = function () {
        if (j >= array.length - i - 1) {
            j = 0;
            i++;
        }
        if (i >= array.length) {
            handleNewState(PRESORT_STATE);
            return;
        }

        highligthElement(j);
        highligthElement(j + 1);

        setTimeout(function () {
            temp = function () {
                if (curRoundConfig.canciled) {
                    unhighligthElement(j);
                    unhighligthElement(j + 1);
                    return
                }
                if (array[j] > array[j + 1]) {
                    swap(j, j + 1)
                }

                setTimeout(function () {
                    temp = function () {
                        unhighligthElement(j);
                        unhighligthElement(j + 1);
                        bubbleSort(i, j + 1, curRoundConfig);
                    }
                    if (curRoundConfig.stopped) {
                        curRoundConfig.noticeFunction = temp
                    } else {
                        temp();
                    }
                }, sortDelay);
            }
            if (curRoundConfig.stopped) {
                curRoundConfig.noticeFunction = temp;
            } else {
                temp();
            }
        }, sortDelay);
    }
    if (curRoundConfig.stopped) {
        curRoundConfig.noticeFunction = temp;
    } else {
        temp();
    }

    /*
    for (let i = 0; i < array.length; i++) {
        for (let j = 0; j < array.length - i - 1; j++) {
            if (array[j] > array[j - 1]) {
                let c = array[j];
                array[j] = array[j - 1];
                array[j - 1] = c;
            }
        }
    }
    */
}

function handleNewState(newState) {
    state = newState;
    switch (state) {
        case PRESORT_STATE:
            inputs.startButton.text("Start")
            break;
        case STOP_STATE:
            inputs.startButton.text("continue")
            break;
        case SORTING_STATE:
            inputs.startButton.text("Stop")
            break;
    }
}

function getSortByName(name) {
    switch (name) {
        case "Bubble sort":
            return bubbleSort;
            break;

        default:
            break;
    }
}

function isConfigCorrect() {
    let result = {
        result: false,
        comment: ""
    }
    if (currentRoundConfig.elementCount !== undefined) {
        if (currentRoundConfig.maxElement !== undefined) {
            if (currentRoundConfig.sortName !== undefined) {
                if (isNumberKey(currentRoundConfig.elementCount)) {
                    if (isNumberKey(currentRoundConfig.maxElement)) {
                        if (currentRoundConfig.elementCount < 100) {
                            if (currentRoundConfig.maxElement < 10000) {
                                if (getSortByName(currentRoundConfig.sortName) !== undefined) {
                                    if (currentRoundConfig.elementCount > 1) {
                                        if (currentRoundConfig.maxElement > 1) {
                                            result.result = true;
                                        } else {
                                            result.comment = "Max element must be greater than 1"
                                        }
                                    } else {
                                        result.comment = "Element count must be greater than 1"
                                    }
                                } else {
                                    result.comment = "Sort name is invalid"
                                }
                            } else {
                                result.comment = "Max element must be less than 10000"
                            }
                        } else {
                            result.comment = "Element count must be less than 100"
                        }
                    } else {
                        result.comment = "Max element is not a number"
                    }
                } else {
                    result.comment = "Element count is not a number"
                }
            } else {
                result.comment = "Sort name is undefined"
            }
        } else {
            result.comment = "Max element is undefined"
        }
    } else {
        result.comment = "Element count is undefined"
    }
    return result
}

$(function () {
    setup();
    $(".generate-button").on("click", function () {
        currentRoundConfig.canciled = true;
        currentRoundConfig = {};
        currentRoundConfig.elementCount = inputs.elementCountInput.val();
        currentRoundConfig.maxElement = inputs.maxElementInput.val();
        currentRoundConfig.sortName = inputs.sortSelector.val();
        currentRoundConfig.canciled = false;
        currentRoundConfig.stopped = false;
        currentRoundConfig.noticeFunction = null;
        let configCheckResult = isConfigCorrect();
        if (configCheckResult.result) {
            genArray();
            createElementsFromArray();
        } else {
            message(configCheckResult.comment)
            currentRoundConfig.canciled = true;
        }
        handleNewState(PRESORT_STATE)
    })
    $(".start-button").on("click", function () {
        if (state === STOP_STATE) {
            currentRoundConfig.stopped = false;
            handleNewState(SORTING_STATE)
            currentRoundConfig.noticeFunction();
        } else if (state === SORTING_STATE) {
            currentRoundConfig.stopped = true;
            handleNewState(STOP_STATE)
        } else {
            handleNewState(SORTING_STATE)
            bubbleSort(0, 0, currentRoundConfig);
        }
    })
});